# AEM Component Documentaion Demo
Lorem Ipsum dollar sit amet.

***

## Title Component

Title component description here.

### Features
- Author can set Title. If it is not authored then it will render default title of current page.
- Author can set Type/Size.
- Author cam set Link.


### Dialog Properties
  
1. **Title** `(TextField)` - Option to set the title.


2. **Type/Size** `(Dropdown)` - option to set tile heading type.  
	There are six options  
    * `h1` (Default)
    * `h2`
    * `h3`
    * `h4`
    * `h5`
    * `h6`


3. **Link** `(PathField)` - Set link for Title.


### Additional Authoring Documentation
There are no additional authoring document available for this component

